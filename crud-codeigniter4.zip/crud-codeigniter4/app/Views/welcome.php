<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<div class="p-5 text-center bg-white rounded-3 shadow-sm">
    <h1 class="text-body-emphasis">Aplikasi CRUD Pegawai</h1>
    <p class="lead">
        Selamat datang di Aplikasi Pegawai. Aplikasi ini digunakan untuk mengelola data pegawai.
    </p>
</div>
<?= $this->endSection(); ?>